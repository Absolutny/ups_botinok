"""Регламентное обслуживание ИС «Учёт техники».
  python maintenance.py — проверка целостности БД, статистика, оптимизация, резервная копия.
Результат выводится на экран и дописывается в maintenance.log.
"""
import os
import sqlite3
from datetime import datetime

from app import app, make_backup

lines = []


def say(text):
    lines.append(text)
    print(text)


db_path = app.config["DATABASE"]
say(f"=== Обслуживание {datetime.now():%d.%m.%Y %H:%M:%S} ===")
con = sqlite3.connect(db_path)
say("Проверка целостности БД: " + con.execute("PRAGMA integrity_check").fetchone()[0])
say("Проверка внешних ключей: " + ("нарушений нет" if not con.execute("PRAGMA foreign_key_check").fetchall() else "ЕСТЬ НАРУШЕНИЯ"))
for title, sql in [
    ("Пользователей", "SELECT COUNT(*) FROM users"),
    ("Единиц техники", "SELECT COUNT(*) FROM equipment"),
    ("Записей журнала", "SELECT COUNT(*) FROM history"),
    ("Дублей инвентарных номеров", "SELECT COUNT(*) FROM (SELECT inv_number FROM equipment GROUP BY inv_number HAVING COUNT(*)>1)"),
    ("Техники без помещения (не списана)", "SELECT COUNT(*) FROM equipment WHERE location_id IS NULL AND status!='Списано'"),
    ("Техники без ответственного (не списана)", "SELECT COUNT(*) FROM equipment WHERE employee_id IS NULL AND status!='Списано'"),
]:
    say(f"{title}: {con.execute(sql).fetchone()[0]}")
size_before = os.path.getsize(db_path)
con.execute("PRAGMA optimize")
con.execute("VACUUM")
con.close()
say(f"Оптимизация БД выполнена (размер {size_before} → {os.path.getsize(db_path)} байт)")
say("Резервная копия: " + make_backup())
with open(os.path.join(os.path.dirname(db_path), "maintenance.log"), "a", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
