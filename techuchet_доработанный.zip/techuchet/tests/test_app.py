import os, re, sys, time, shutil, tempfile
sys.path.insert(0, sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
tmp = tempfile.mkdtemp()
os.environ["DATABASE"] = tmp + "/t.db"; os.environ["BACKUP_DIR"] = tmp + "/b"
import app as A
A.init_db(); app = A.app
res = []
def check(name, cond): res.append((name, bool(cond))); print(("OK  " if cond else "FAIL"), name)
def client():
    return app.test_client()
def tok(c, path="/login"):
    h = c.get(path).get_data(as_text=True); m = re.search(r'name="_csrf" value="([^"]+)"', h); return m.group(1) if m else None
def login(c, u, p):
    t = tok(c); return c.post("/login", data={"login": u, "password": p, "_csrf": t})
c = client()
check("З-1 без входа редирект на /login", c.get("/equipment").status_code == 302 and "/login" in c.get("/equipment").location)
check("З-4 POST без CSRF отклоняется", c.post("/login", data={"login": "admin", "password": "admin123"}).status_code == 400)
check("Неверный пароль не пускает", "Неверный логин" in login(c, "admin", "bad").get_data(as_text=True))
r = login(c, "admin", "admin123"); check("Вход admin/admin123", r.status_code == 302)
r = c.get("/equipment"); check("З-6 принудительная смена пароля по умолчанию", r.status_code == 302 and "/password" in r.location)
t = tok(c, "/password")
r = c.post("/password", data={"old": "admin123", "new": "123", "_csrf": t}); check("Пароль < 6 символов отклонён", "не менее 6" in r.get_data(as_text=True))
r = c.post("/password", data={"old": "admin123", "new": "Admin#2026", "_csrf": t}); check("Смена пароля", r.status_code == 302)
check("После смены реестр доступен", c.get("/equipment").status_code == 200)
# справочные данные
t = tok(c, "/dict/categories")
for n in ["Ноутбуки", "Мониторы"]: c.post("/dict/categories", data={"name": n, "_csrf": t})
c.post("/dict/locations", data={"name": "Кабинет 1", "_csrf": t}); c.post("/dict/employees", data={"name": "Петров П. П.", "_csrf": t})
r = c.post("/dict/categories", data={"name": "Ноутбуки", "_csrf": t}, follow_redirects=True); check("Дубль справочника отклонён", "уже есть" in r.get_data(as_text=True))
t = tok(c, "/equipment/new")
form = dict(inv_number="T-1", name="Тест", category_id="1", serial_number="S1", purchase_date="2026-01-01", price="1000,5", location_id="1", employee_id="1", status="В эксплуатации", note="", _csrf=t)
r = c.post("/equipment/new", data=form); check("Ф-2 постановка на учёт", r.status_code == 302)
r = c.post("/equipment/new", data=form, follow_redirects=True); check("Дубль инв. номера отклонён", "уже есть" in r.get_data(as_text=True))
r = c.post("/equipment/new", data={**form, "inv_number": "T-2", "price": "-5"}, follow_redirects=True); check("Отрицательная цена отклонена", "неотрицательным" in r.get_data(as_text=True))
r = c.post("/equipment/new", data={**form, "inv_number": "T-3", "purchase_date": "31.02.2026"}, follow_redirects=True); check("Неверная дата отклонена", "Неверная дата" in r.get_data(as_text=True))
r = c.post("/equipment/1/status", data={"status": "Списано", "reason": "", "_csrf": t}, follow_redirects=True); check("Ф-5 списание без причины запрещено", "укажите причину" in r.get_data(as_text=True))
r = c.post("/equipment/1/status", data={"status": "Списано", "reason": "Износ", "_csrf": t}, follow_redirects=True); check("Списание с причиной", "Статус изменён" in r.get_data(as_text=True))
r = c.post("/equipment/1/move", data={"location_id": "1", "employee_id": "1", "_csrf": t}); check("Ф-4 перемещение", r.status_code == 302)
h = c.get("/equipment/1").get_data(as_text=True); check("Ф-6 журнал содержит операции", all(k in h for k in ("Перемещение", "Списание", "Постановка на учёт")))
check("Ф-8 CSV", c.get("/equipment/export.csv").get_data(as_text=True).startswith("﻿Инв. номер;"))
check("Журнал операций", c.get("/journal").status_code == 200 and c.get("/journal?kind=Списание").status_code == 200)
check("Сводка", "Сводка" in c.get("/").get_data(as_text=True))
check("Ф-12 резервная копия", c.post("/backups", data={"_csrf": t}).status_code == 302 and len(os.listdir(tmp + "/b")) == 1)
fn = os.listdir(tmp + "/b")[0]; check("Скачивание копии", c.get("/backups/" + fn).status_code == 200)
# пользователи и роли
c.post("/users", data={"login": "op", "full_name": "Опер", "role": "operator", "password": "oper123", "_csrf": t})
c.post("/users", data={"login": "vw", "full_name": "Набл", "role": "viewer", "password": "view123", "_csrf": t})
r = c.post("/users", data={"login": "op", "full_name": "Опер", "role": "operator", "password": "oper123", "_csrf": t}, follow_redirects=True); check("Дубль логина отклонён", "уже существует" in r.get_data(as_text=True))
r = c.post("/users/1/edit", data={"role": "viewer", "_csrf": t}, follow_redirects=True); check("Нельзя понизить себя", "Нельзя снять" in r.get_data(as_text=True))
r = c.post("/users/1/delete", data={"_csrf": t}, follow_redirects=True); check("Нельзя удалить себя", "Нельзя удалить" in r.get_data(as_text=True))
c.post("/users/2/edit", data={"role": "operator", "password": "newpass1", "_csrf": t})
r = c.post("/dict/categories/1/delete", data={"_csrf": t}, follow_redirects=True); check("Ф-10 удаление используемой записи запрещено", "используется" in r.get_data(as_text=True))
r = c.post("/dict/locations/1/rename", data={"name": "Склад №1", "_csrf": t}, follow_redirects=True); check("Переименование справочника", "Название изменено" in r.get_data(as_text=True))
o = client(); login(o, "op", "newpass1"); o.post("/password", data={"old": "newpass1", "new": "oper456", "_csrf": tok(o, "/password")}); 
check("Оператор: после смены пароля вход", o.get("/equipment").status_code == 200)
check("З-3 оператор: пользователи — 403", o.get("/users").status_code == 403)
check("З-3 оператор: копии — 403", o.get("/backups").status_code == 403)
check("Оператор: справочники доступны", o.get("/dict/categories").status_code == 200)
to = tok(o, "/equipment/new"); r = o.post("/dict/categories/2/delete", data={"_csrf": to}); check("Ф-10 оператор не удаляет из справочника", r.status_code == 403)
v = client(); login(v, "vw", "view123"); v.post("/password", data={"old": "view123", "new": "view456", "_csrf": tok(v, "/password")})
check("Наблюдатель видит реестр", v.get("/equipment").status_code == 200)
check("З-3 наблюдатель: постановка — 403", v.get("/equipment/new").status_code == 403)
tv = tok(v, "/equipment"); check("З-3 наблюдатель: смена статуса — 403", v.post("/equipment/1/status", data={"status": "На складе", "_csrf": tv}).status_code == 403)
check("Страница 404", c.get("/equipment/9999").status_code == 404)
check("Параметризация: SQL-инъекция в поиске безопасна", c.get("/equipment?q=' OR 1=1 --").status_code == 200 and "Ничего не найдено" in c.get("/equipment?q=' OR 1=1 --").get_data(as_text=True))
check("Сортировка с неверным полем безопасна", c.get("/equipment?sort=x;drop").status_code == 200)
check("З-7 ключ не в коде", os.path.isfile(tmp + "/secret.key") and "change-me" not in open(os.path.join(os.path.dirname(A.__file__), "app.py"), encoding="utf-8").read())
c.post("/logout", data={"_csrf": t}); check("Ф-1 выход", c.get("/equipment").status_code == 302)
# производительность 5000
import sqlite3
db = sqlite3.connect(os.environ["DATABASE"])
db.executemany("INSERT INTO equipment(inv_number,name,category_id,serial_number,purchase_date,price,location_id,employee_id,status) VALUES (?,?,?,?,?,?,?,?,?)",
  [(f"P-{i:05d}", f"Монитор модель {i}", 1, f"SN{i}", "2024-01-01", 10000 + i, 1, 1, "В эксплуатации") for i in range(5000)]); db.commit()
c = client(); login(c, "admin", "Admin#2026")
for url in ["/equipment", "/equipment?q=модель 42", "/equipment?sort=price&dir=desc&page=30", "/"]:
    s = time.perf_counter(); r = c.get(url); d = time.perf_counter() - s
    check(f"Ф-14 {url} за {d:.2f} c (<2)", r.status_code == 200 and d < 2)
print(sum(1 for _, ok in res if ok), "/", len(res)); shutil.rmtree(tmp)
