"""Резервное копирование и восстановление БД.
  python backup.py                   — создать копию (хранятся последние 30)
  python backup.py restore <файл.db> — восстановить из копии (проверяет целостность)
"""
import os
import shutil
import sqlite3
import sys

from app import app, make_backup


def integrity_ok(path):
    try:
        con = sqlite3.connect(path)
        res = con.execute("PRAGMA integrity_check").fetchone()[0]
        con.close()
        return res == "ok"
    except sqlite3.DatabaseError:
        return False


if len(sys.argv) >= 3 and sys.argv[1] == "restore":
    src = sys.argv[2]
    if not os.path.isfile(src):
        sys.exit(f"Файл не найден: {src}")
    if not integrity_ok(src):
        sys.exit("Копия повреждена, восстановление отменено")
    if os.path.isfile(app.config["DATABASE"]):
        shutil.copy2(app.config["DATABASE"], app.config["DATABASE"] + ".before_restore")
    shutil.copy2(src, app.config["DATABASE"])
    print("База данных восстановлена из", src)
else:
    print("Создана копия:", make_backup())
