ИС «Учёт техники» (Flask + SQLite)

Запуск
  pip install -r requirements.txt
  python app.py                       -> http://127.0.0.1:5000
  Для доступа по сети: python -m flask --app app run --host 0.0.0.0

Первый вход: логин admin, пароль admin123 (если БД новая) — система потребует сменить пароль.
Ваши данные находятся в instance/techuchet.db (старая БД подхватывается автоматически,
в таблицу users добавляется столбец must_change).

Демо-данные (как на скриншотах отчёта, 41 единица техники):
  Windows (cmd):  set DATABASE=demo_data\techuchet_demo.db && python app.py
  Linux/macOS:    DATABASE=demo_data/techuchet_demo.db python app.py
  Учётные записи демо: admin / Admin#2026 (администратор), petrova / oper2026 (оператор), sidorov / view2026 (наблюдатель)

Резервное копирование и обслуживание
  python backup.py                    создать копию (хранятся последние 30)
  python backup.py restore backups/<файл>.db
  python maintenance.py               проверка БД, оптимизация, копия; журнал: instance/maintenance.log

Проверка
  python tests/test_app.py            44 автоматические проверки
